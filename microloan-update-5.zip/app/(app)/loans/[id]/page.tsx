import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getLoan, refreshOverdueInstallments } from '@/lib/data';
import { money, statusBadgeClass } from '@/lib/utils';
import { updateLoanStatusAction, deleteLoanAction, finalizeDraftLoanAction, updateInstallmentParticularsAction, updateLoanMaturityDateAction } from '@/lib/actions';
import BackLink from '../../BackLink';

export const metadata = { title: 'Loan Details - MicroLoan Admin' };

export default async function LoanViewPage({ params }: { params: { id: string } }) {
  const id = Number(params.id);
  if (!id || isNaN(id)) notFound();
  await refreshOverdueInstallments();
  const data = await getLoan(id);
  if (!data) notFound();
  const { loan, installments } = data;

  const paidTotal = (installments as any[]).reduce((s, i) => s + Number(i.paid_amount), 0);
  const isDraft = loan.status === 'draft';

  return (
    <div>
      <div className="flex flex-wrap justify-between items-start gap-3 mb-4">
        <div className="flex items-center gap-3">
          <BackLink />
          <div>
            <h1 className="text-lg font-bold text-navy flex items-center gap-2">
              {loan.loan_code} <span className={`badge ${statusBadgeClass(loan.status)}`}>{loan.status}</span>
            </h1>
            <p className="text-gray-500 text-sm">
              Member: <Link href={`/borrowers/${loan.borrower_id}`} className="text-teal">{loan.full_name}</Link> ({loan.borrower_code}) — {loan.phone}
            </p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {isDraft && (
            <>
              <Link href={`/loans/${id}/edit-draft`} className="btn btn-outline">✏️ Edit Draft</Link>
              <form action={finalizeDraftLoanAction.bind(null, id)}><button className="btn btn-primary">✔ Done — Register Loan</button></form>
            </>
          )}
          {loan.status === 'pending' && (
            <>
              <form action={updateLoanStatusAction.bind(null, id, 'approve')}><button className="btn btn-primary !bg-green-600">✅ Approve</button></form>
              <form action={updateLoanStatusAction.bind(null, id, 'reject')}><button className="btn btn-danger-outline">❌ Reject</button></form>
            </>
          )}
          {loan.status === 'approved' && (
            <form action={updateLoanStatusAction.bind(null, id, 'activate')}><button className="btn btn-primary">▶ Mark Active / Disburse</button></form>
          )}
          {!isDraft && <Link href={`/collections/${id}`} className="btn btn-outline">💵 Collect Payment</Link>}
          <Link href="/loans" className="btn btn-outline">✔ Done</Link>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <div className="card p-4"><div className="text-lg font-bold text-navy">৳{money(loan.loan_amount)}</div><div className="text-xs text-gray-500">Principal</div></div>
        <div className="card p-4"><div className="text-lg font-bold text-navy">{loan.interest_rate}%</div><div className="text-xs text-gray-500">{loan.interest_type} Interest (calculated)</div></div>
        <div className="card p-4"><div className="text-lg font-bold text-navy">৳{money(loan.total_payable)}</div><div className="text-xs text-gray-500">Total Payable</div></div>
        <div className="card p-4"><div className="text-lg font-bold text-navy">৳{money(Number(loan.total_payable) - paidTotal)}</div><div className="text-xs text-gray-500">Balance Remaining</div></div>
      </div>

      {!isDraft && (
        <div className="card p-4 mb-4 flex flex-wrap items-center gap-3">
          <span className="text-xs text-gray-500 font-semibold">📅 Maturity Date:</span>
          <form action={updateLoanMaturityDateAction.bind(null, id)} className="flex items-center gap-2">
            <input
              type="date"
              name="maturity_date"
              defaultValue={loan.maturity_date ? new Date(loan.maturity_date).toISOString().slice(0, 10) : ''}
              className="input !py-1 !px-2 text-sm w-40"
            />
            <button type="submit" className="btn btn-outline !py-1 !px-3 text-xs">Save</button>
          </form>
        </div>
      )}

      {isDraft ? (
        <div className="card p-6 text-center text-gray-500 text-sm">
          This loan is still a draft — no installment schedule has been generated yet. Click <strong>Edit Draft</strong> to fill in the details, then <strong>Done — Register Loan</strong> to finalize it.
        </div>
      ) : (
        <div className="table-wrap">
          <div className="px-4 py-3 border-b border-gray-100 font-semibold text-sm">Installment Schedule</div>
          <table className="app-table">
            <thead>
              <tr>
                <th>#</th><th>Date</th><th>Particulars</th><th>Amount</th><th>Total Paid</th>
                <th>Remaining Balance</th><th>Receipt</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {(() => {
                let cumulativePaid = 0;
                return (installments as any[]).map((i) => {
                  cumulativePaid += Number(i.paid_amount);
                  // "Total Paid" and "Remaining Balance" here are running totals for the
                  // WHOLE loan through this installment — not just this row's own amount —
                  // so they read the same way a bank passbook does.
                  const totalRemaining = Math.max(0, Number(loan.total_payable) - cumulativePaid);
                  return (
                    <tr key={i.id}>
                      <td>{i.installment_no}</td>
                      <td>{new Date(i.due_date).toLocaleDateString()}</td>
                      <td>
                        <form action={updateInstallmentParticularsAction.bind(null, id, i.id)} className="flex gap-1">
                          <input name="particulars" defaultValue={i.particulars || ''} placeholder="Installment" className="input !py-1 !px-2 text-xs w-28" />
                          <button type="submit" className="text-xs text-teal hover:underline flex-shrink-0">Save</button>
                        </form>
                      </td>
                      <td>৳{money(i.amount)}</td>
                      <td>৳{money(cumulativePaid)}</td>
                      <td className="font-semibold">৳{money(totalRemaining)}</td>
                      <td>{i.receipt_no ? <Link href={`/collections/receipt/${i.receipt_id}`} className="text-teal text-xs">{i.receipt_no}</Link> : '—'}</td>
                      <td><span className={`badge ${statusBadgeClass(i.status)}`}>{i.status}</span></td>
                      <td>{i.status !== 'paid' && <Link href={`/collections/${id}?installment_id=${i.id}`} className="btn btn-outline !py-1 !px-2 text-xs">Collect</Link>}</td>
                    </tr>
                  );
                });
              })()}
            </tbody>
          </table>
        </div>
      )}

      {loan.status === 'pending' || loan.status === 'rejected' || isDraft ? (
        <form action={deleteLoanAction.bind(null, id)} className="mt-4">
          <button className="text-xs text-red-400 hover:text-red-600 confirm-delete">🗑 Delete this loan</button>
        </form>
      ) : null}
    </div>
  );
}
