'use server';

import bcrypt from 'bcryptjs';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { sql } from './db';
import { createSession, destroySession, getSession } from './auth';
import { generateScheduleFromInstallment } from './utils';

async function requireAdmin() {
  const session = await getSession();
  if (!session) redirect('/login');
  return session!;
}

/**
 * Sequential codes use a letter prefix by type, plus a 4-digit sequential
 * number scoped to that type/table: R for loan-payment receipts (collections),
 * S for savings, M for member (registration) fees, P for processing fees,
 * L for loan codes. Each prefix has its own independent counter.
 */
async function nextSequentialCode(
  prefix: 'R' | 'S' | 'M' | 'P' | 'L',
  table: 'collections' | 'savings_transactions' | 'borrowers' | 'loans',
  column: 'receipt_no' | 'fee_receipt_no' | 'loan_code'
): Promise<string> {
  const pattern = `^${prefix}[0-9]{4}$`;
  let row: any;
  if (table === 'collections') {
    [row] = await sql`SELECT COALESCE(MAX(SUBSTRING(receipt_no FROM 2)::int), 0) AS max_n FROM collections WHERE receipt_no ~ ${pattern}`;
  } else if (table === 'savings_transactions') {
    [row] = await sql`SELECT COALESCE(MAX(SUBSTRING(receipt_no FROM 2)::int), 0) AS max_n FROM savings_transactions WHERE receipt_no ~ ${pattern}`;
  } else if (table === 'loans') {
    [row] = await sql`SELECT COALESCE(MAX(SUBSTRING(loan_code FROM 2)::int), 0) AS max_n FROM loans WHERE loan_code ~ ${pattern}`;
  } else {
    [row] = await sql`SELECT COALESCE(MAX(SUBSTRING(fee_receipt_no FROM 2)::int), 0) AS max_n FROM borrowers WHERE fee_receipt_no ~ ${pattern}`;
  }
  const next = Number(row.max_n) + 1;
  return prefix + String(next).padStart(4, '0');
}

// ---------- Auth ----------

export async function loginAction(formData: FormData) {
  const email = String(formData.get('email') || '').trim();
  const password = String(formData.get('password') || '');

  if (!email || !password) {
    return { error: 'Please enter both email and password.' };
  }

  const [admin] = await sql`SELECT * FROM admins WHERE email = ${email} LIMIT 1`;
  if (!admin || !(await bcrypt.compare(password, admin.password))) {
    return { error: 'Invalid email or password.' };
  }
  if (admin.status !== 'active') {
    return { error: 'Your account has been deactivated.' };
  }

  await createSession({ adminId: admin.id, name: admin.full_name, email: admin.email, role: admin.role });
  redirect('/dashboard');
}

export async function logoutAction() {
  await destroySession();
  redirect('/login');
}

// ---------- Borrowers (Members) ----------

export async function createBorrowerAction(formData: FormData) {
  const admin = await requireAdmin();

  const memberId = String(formData.get('member_id') || '').trim();
  const fullName = String(formData.get('full_name') || '').trim();
  const phone = String(formData.get('phone') || '').trim();
  if (!fullName || !phone) {
    redirect('/borrowers/new?error=' + encodeURIComponent('Full name and phone are required.'));
  }
  if (!memberId) {
    redirect('/borrowers/new?error=' + encodeURIComponent('Member ID is required.'));
  }

  const regFee = Number(formData.get('registration_fee') || 0);
  const feeReceiptNo = regFee > 0 ? await nextSequentialCode('M', 'borrowers', 'fee_receipt_no') : null;

  let row: any;
  try {
    [row] = await sql`
      INSERT INTO borrowers
        (borrower_code, full_name, father_name, gender, phone, email, nid_number, present_address, occupation, monthly_income, guarantor_name, guarantor_phone, registration_fee, fee_receipt_no, status, created_by)
      VALUES (
        ${memberId}, ${fullName}, ${String(formData.get('father_name') || '')}, ${String(formData.get('gender') || 'male')},
        ${phone}, ${String(formData.get('email') || '')}, ${String(formData.get('nid_number') || '')},
        ${String(formData.get('present_address') || '')}, ${String(formData.get('occupation') || '')},
        ${Number(formData.get('monthly_income') || 0)}, ${String(formData.get('guarantor_name') || '')},
        ${String(formData.get('guarantor_phone') || '')}, ${regFee}, ${feeReceiptNo}, 'active', ${admin.adminId}
      )
      RETURNING id
    `;
  } catch (err: any) {
    const msg = String(err?.message || '');
    if (err?.code === '23505' || msg.includes('duplicate key') || msg.includes('already exists')) {
      redirect('/borrowers/new?error=' + encodeURIComponent(`Member ID "${memberId}" is already in use — please choose a different one.`));
    }
    throw err;
  }

  revalidatePath('/borrowers');
  revalidatePath('/loans/new');
  redirect(`/borrowers/${row.id}`);
}

export async function updateBorrowerAction(id: number, formData: FormData) {
  await requireAdmin();

  const memberId = String(formData.get('member_id') || '').trim();
  if (!memberId) {
    redirect(`/borrowers/${id}/edit?error=` + encodeURIComponent('Member ID is required.'));
  }

  try {
    await sql`
      UPDATE borrowers SET
        borrower_code = ${memberId},
        full_name = ${String(formData.get('full_name') || '')},
        father_name = ${String(formData.get('father_name') || '')},
        gender = ${String(formData.get('gender') || 'male')},
        phone = ${String(formData.get('phone') || '')},
        email = ${String(formData.get('email') || '')},
        nid_number = ${String(formData.get('nid_number') || '')},
        present_address = ${String(formData.get('present_address') || '')},
        occupation = ${String(formData.get('occupation') || '')},
        monthly_income = ${Number(formData.get('monthly_income') || 0)},
        guarantor_name = ${String(formData.get('guarantor_name') || '')},
        guarantor_phone = ${String(formData.get('guarantor_phone') || '')},
        registration_fee = ${Number(formData.get('registration_fee') || 0)},
        status = ${String(formData.get('status') || 'active')}
      WHERE id = ${id}
    `;
  } catch (err: any) {
    const msg = String(err?.message || '');
    if (err?.code === '23505' || msg.includes('duplicate key') || msg.includes('already exists')) {
      redirect(`/borrowers/${id}/edit?error=` + encodeURIComponent(`Member ID "${memberId}" is already in use — please choose a different one.`));
    }
    throw err;
  }

  revalidatePath('/borrowers');
  revalidatePath(`/borrowers/${id}`);
  revalidatePath('/loans/new');
  redirect(`/borrowers/${id}`);
}

// Removing a member moves them (and all their loans) to the Bin instead of
// deleting anything for real — nothing is destroyed, and everything can be
// restored together later from /bin.
export async function deleteBorrowerAction(id: number) {
  await requireAdmin();
  await sql`UPDATE borrowers SET deleted_at = now() WHERE id = ${id}`;
  await sql`UPDATE loans SET deleted_at = now() WHERE borrower_id = ${id} AND deleted_at IS NULL`;
  revalidatePath('/borrowers');
  revalidatePath('/loans');
  revalidatePath('/bin');
  redirect('/borrowers');
}

export async function restoreBorrowerAction(id: number) {
  await requireAdmin();
  await sql`UPDATE borrowers SET deleted_at = NULL WHERE id = ${id}`;
  await sql`UPDATE loans SET deleted_at = NULL WHERE borrower_id = ${id}`;
  revalidatePath('/borrowers');
  revalidatePath('/loans');
  revalidatePath('/bin');
  redirect('/bin');
}

// ---------- Loans ----------
// Registration now takes the loan amount, the installment amount, and the
// number of installments — the interest rate is DERIVED from those, not
// entered directly (see lib/utils.ts generateScheduleFromInstallment).

export async function createLoanAction(formData: FormData) {
  const admin = await requireAdmin();

  const borrowerId = Number(formData.get('borrower_id'));
  const amount = Number(formData.get('loan_amount'));
  const installmentAmount = Number(formData.get('installment_amount'));
  const interestType = String(formData.get('interest_type') || 'flat');
  const tenure = Number(formData.get('tenure'));
  const frequency = String(formData.get('repayment_frequency') || 'monthly') as 'daily' | 'weekly' | 'monthly';
  const purpose = String(formData.get('purpose') || '');
  const disbursed = String(formData.get('disbursement_date') || new Date().toISOString().slice(0, 10));
  const maturityDate = String(formData.get('maturity_date') || '') || null;

  if (!borrowerId || amount <= 0 || tenure <= 0 || installmentAmount <= 0) {
    redirect('/loans/new?error=' + encodeURIComponent('Please fill in all required loan fields correctly.'));
  }

  const schedule = generateScheduleFromInstallment(amount, installmentAmount, tenure, frequency, disbursed);
  const code = await nextSequentialCode('L', 'loans', 'loan_code');

  const [loan] = await sql`
    INSERT INTO loans
      (loan_code, borrower_id, loan_amount, interest_rate, interest_type, tenure, repayment_frequency, total_payable, installment_amount, purpose, disbursement_date, maturity_date, status, created_by)
    VALUES (
      ${code}, ${borrowerId}, ${amount}, ${schedule.interestRate}, ${interestType}, ${tenure}, ${frequency},
      ${schedule.totalPayable}, ${schedule.installmentAmount}, ${purpose}, ${disbursed}, ${maturityDate}, 'pending', ${admin.adminId}
    )
    RETURNING id
  `;

  for (const inst of schedule.installments) {
    await sql`
      INSERT INTO loan_installments (loan_id, installment_no, due_date, amount)
      VALUES (${loan.id}, ${inst.installmentNo}, ${inst.dueDate}, ${inst.amount})
    `;
  }

  revalidatePath('/loans');
  redirect(`/loans/${loan.id}`);
}

/**
 * Saves a loan as a draft — the fields the admin has filled in so far, with no
 * installment schedule generated yet (that only happens once the draft is
 * finalized via finalizeDraftLoanAction, since the schedule depends on having
 * real values for amount/installment/tenure).
 */
export async function saveDraftLoanAction(formData: FormData) {
  const admin = await requireAdmin();

  const borrowerId = Number(formData.get('borrower_id')) || null;
  const amount = Number(formData.get('loan_amount')) || 0;
  const installmentAmount = Number(formData.get('installment_amount')) || 0;
  const interestType = String(formData.get('interest_type') || 'flat');
  const tenure = Number(formData.get('tenure')) || 0;
  const frequency = String(formData.get('repayment_frequency') || 'monthly');
  const purpose = String(formData.get('purpose') || '');
  const disbursed = String(formData.get('disbursement_date') || new Date().toISOString().slice(0, 10));
  const maturityDate = String(formData.get('maturity_date') || '') || null;

  if (!borrowerId) {
    redirect('/loans/new?error=' + encodeURIComponent('Please select a member before saving a draft.'));
  }

  const code = await nextSequentialCode('L', 'loans', 'loan_code');
  const [loan] = await sql`
    INSERT INTO loans
      (loan_code, borrower_id, loan_amount, interest_type, tenure, repayment_frequency, purpose, disbursement_date, maturity_date, installment_amount, status, created_by)
    VALUES (${code}, ${borrowerId}, ${amount}, ${interestType}, ${tenure}, ${frequency}, ${purpose}, ${disbursed}, ${maturityDate}, ${installmentAmount}, 'draft', ${admin.adminId})
    RETURNING id
  `;

  revalidatePath('/loans');
  redirect(`/loans/${loan.id}`);
}

/** Turns a draft into a real registered loan — generates the installment schedule now. */
export async function finalizeDraftLoanAction(id: number) {
  await requireAdmin();

  const [loan] = await sql`SELECT * FROM loans WHERE id = ${id} AND status = 'draft'`;
  if (!loan) redirect('/loans?error=' + encodeURIComponent('Draft not found.'));

  const amount = Number(loan.loan_amount);
  const installmentAmount = Number(loan.installment_amount);
  const tenure = Number(loan.tenure);
  if (amount <= 0 || installmentAmount <= 0 || tenure <= 0) {
    redirect(`/loans/${id}/edit-draft?error=` + encodeURIComponent('Fill in the loan amount, installment amount, and tenure before finalizing.'));
  }

  const disbursed = loan.disbursement_date ? new Date(loan.disbursement_date).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10);
  const schedule = generateScheduleFromInstallment(amount, installmentAmount, tenure, loan.repayment_frequency, disbursed);

  await sql`
    UPDATE loans SET interest_rate = ${schedule.interestRate}, total_payable = ${schedule.totalPayable}, status = 'pending'
    WHERE id = ${id}
  `;

  for (const inst of schedule.installments) {
    await sql`
      INSERT INTO loan_installments (loan_id, installment_no, due_date, amount)
      VALUES (${id}, ${inst.installmentNo}, ${inst.dueDate}, ${inst.amount})
    `;
  }

  revalidatePath('/loans');
  revalidatePath(`/loans/${id}`);
  redirect('/loans');
}

export async function updateDraftLoanAction(id: number, formData: FormData) {
  await requireAdmin();

  const borrowerId = Number(formData.get('borrower_id')) || null;
  const amount = Number(formData.get('loan_amount')) || 0;
  const installmentAmount = Number(formData.get('installment_amount')) || 0;
  const interestType = String(formData.get('interest_type') || 'flat');
  const tenure = Number(formData.get('tenure')) || 0;
  const frequency = String(formData.get('repayment_frequency') || 'monthly');
  const purpose = String(formData.get('purpose') || '');
  const disbursed = String(formData.get('disbursement_date') || new Date().toISOString().slice(0, 10));
  const maturityDate = String(formData.get('maturity_date') || '') || null;

  await sql`
    UPDATE loans SET borrower_id = ${borrowerId}, loan_amount = ${amount}, installment_amount = ${installmentAmount},
      interest_type = ${interestType}, tenure = ${tenure}, repayment_frequency = ${frequency}, purpose = ${purpose},
      disbursement_date = ${disbursed}, maturity_date = ${maturityDate}
    WHERE id = ${id} AND status = 'draft'
  `;

  revalidatePath(`/loans/${id}`);
  redirect(`/loans/${id}`);
}

export async function updateInstallmentParticularsAction(loanId: number, installmentId: number, formData: FormData) {
  await requireAdmin();
  const particulars = String(formData.get('particulars') || '').trim() || null;
  await sql`UPDATE loan_installments SET particulars = ${particulars} WHERE id = ${installmentId} AND loan_id = ${loanId}`;
  revalidatePath(`/loans/${loanId}`);
  redirect(`/loans/${loanId}`);
}

/** Edits the loan's maturity date directly from the loan detail page. */
export async function updateLoanMaturityDateAction(loanId: number, formData: FormData) {
  await requireAdmin();
  const maturityDate = String(formData.get('maturity_date') || '') || null;
  await sql`UPDATE loans SET maturity_date = ${maturityDate} WHERE id = ${loanId}`;
  revalidatePath(`/loans/${loanId}`);
  redirect(`/loans/${loanId}`);
}

const LOAN_STATUS_MAP: Record<string, string> = {
  approve: 'approved',
  reject: 'rejected',
  activate: 'active',
  complete: 'completed',
  default: 'defaulted',
};

export async function updateLoanStatusAction(id: number, action: string): Promise<void> {
  const admin = await requireAdmin();
  const newStatus = LOAN_STATUS_MAP[action];
  if (!newStatus) return;

  await sql`UPDATE loans SET status = ${newStatus}, approved_by = ${admin.adminId} WHERE id = ${id}`;
  revalidatePath(`/loans/${id}`);
  revalidatePath('/loans');
}

// Moves the loan to the Bin (soft delete) instead of destroying it — it can be
// restored later from /bin. Loans that already have payment history are still
// not removable this way, since hiding money that's already been collected
// would make reports inconsistent.
export async function deleteLoanAction(id: number) {
  await requireAdmin();
  const [{ c }] = await sql`SELECT COUNT(*)::int AS c FROM collections WHERE loan_id = ${id}`;
  if (c > 0) {
    redirect('/loans?error=' + encodeURIComponent('Cannot delete a loan with recorded payments.'));
  }
  await sql`UPDATE loans SET deleted_at = now() WHERE id = ${id}`;
  revalidatePath('/loans');
  revalidatePath('/bin');
  redirect('/loans');
}

export async function restoreLoanAction(id: number) {
  await requireAdmin();
  const [loan] = await sql`SELECT borrower_id FROM loans WHERE id = ${id}`;
  await sql`UPDATE loans SET deleted_at = NULL WHERE id = ${id}`;
  if (loan) {
    // If the loan's member is also in the Bin, bring them back too — an active
    // loan shouldn't end up attached to a still-hidden member.
    await sql`UPDATE borrowers SET deleted_at = NULL WHERE id = ${loan.borrower_id} AND deleted_at IS NOT NULL`;
  }
  revalidatePath('/loans');
  revalidatePath('/borrowers');
  revalidatePath('/bin');
  redirect('/bin');
}

// ---------- Collections ----------

async function applyPaymentToInstallments(
  loanId: number,
  amount: number,
  startInstallmentId: number | null,
  paymentDate: string
): Promise<{ appliedAmount: number; firstInstallmentId: number | null }> {
  const installments = (await sql`
    SELECT * FROM loan_installments WHERE loan_id = ${loanId} AND status != 'paid' ORDER BY installment_no ASC
  `) as any[];

  const ordered = startInstallmentId
    ? [...installments.filter((i) => i.id === startInstallmentId), ...installments.filter((i) => i.id !== startInstallmentId)]
    : installments;

  let remaining = amount;
  let firstInstallmentId: number | null = null;

  for (const inst of ordered) {
    if (remaining <= 0) break;
    const due = Number(inst.amount) - Number(inst.paid_amount);
    const payNow = Math.min(remaining, due);
    if (payNow <= 0) continue;
    if (firstInstallmentId === null) firstInstallmentId = inst.id;

    const newPaid = Number(inst.paid_amount) + payNow;
    const newStatus = newPaid >= Number(inst.amount) ? 'paid' : 'partial';
    const paidDate = newStatus === 'paid' ? paymentDate : null;

    await sql`
      UPDATE loan_installments SET paid_amount = ${newPaid}, status = ${newStatus}, paid_date = ${paidDate}
      WHERE id = ${inst.id}
    `;

    remaining -= payNow;
  }

  const appliedAmount = Math.round((amount - Math.max(remaining, 0)) * 100) / 100;
  return { appliedAmount, firstInstallmentId };
}

async function recomputeLoanCompletionStatus(loanId: number) {
  const [{ c: remainingUnpaid }] = await sql`
    SELECT COUNT(*)::int AS c FROM loan_installments WHERE loan_id = ${loanId} AND status != 'paid'
  `;
  const [loan] = await sql`SELECT status FROM loans WHERE id = ${loanId}`;
  if (remainingUnpaid === 0 && loan.status !== 'completed') {
    await sql`UPDATE loans SET status = 'completed' WHERE id = ${loanId}`;
  } else if (remainingUnpaid > 0 && loan.status === 'completed') {
    await sql`UPDATE loans SET status = 'active' WHERE id = ${loanId}`;
  }
}

export async function collectPaymentAction(formData: FormData) {
  const admin = await requireAdmin();

  const loanId = Number(formData.get('loan_id'));
  const startInstallmentId = Number(formData.get('installment_id') || 0);
  const amount = Number(formData.get('amount_paid'));
  const method = String(formData.get('payment_method') || 'cash');
  const paymentDate = String(formData.get('payment_date') || new Date().toISOString().slice(0, 10));
  const notes = String(formData.get('notes') || '');

  if (!loanId || amount <= 0) {
    redirect(`/collections/${loanId}?error=` + encodeURIComponent('Payment amount must be greater than zero.'));
  }

  const [loan] = await sql`SELECT * FROM loans WHERE id = ${loanId}`;
  if (!loan) redirect('/collections?error=' + encodeURIComponent('Loan not found.'));

  const { appliedAmount, firstInstallmentId } = await applyPaymentToInstallments(loanId, amount, startInstallmentId || null, paymentDate);

  const receiptNo = await nextSequentialCode('R', 'collections', 'receipt_no');

  let collection: any;
  try {
    [collection] = await sql`
      INSERT INTO collections (receipt_no, loan_id, installment_id, borrower_id, amount_paid, payment_method, payment_date, notes, collected_by)
      VALUES (${receiptNo}, ${loanId}, ${firstInstallmentId}, ${loan.borrower_id}, ${appliedAmount}, ${method}, ${paymentDate}, ${notes}, ${admin.adminId})
      RETURNING id
    `;
  } catch (err: any) {
    const msg = String(err?.message || '');
    if (msg.includes('installment_id') && msg.includes('does not exist')) {
      [collection] = await sql`
        INSERT INTO collections (receipt_no, loan_id, borrower_id, amount_paid, payment_method, payment_date, notes, collected_by)
        VALUES (${receiptNo}, ${loanId}, ${loan.borrower_id}, ${appliedAmount}, ${method}, ${paymentDate}, ${notes}, ${admin.adminId})
        RETURNING id
      `;
    } else {
      throw err;
    }
  }

  await recomputeLoanCompletionStatus(loanId);

  await sql`
    INSERT INTO notifications (loan_id, borrower_id, title, message, type)
    VALUES (${loanId}, ${loan.borrower_id}, 'Payment received', ${`Received ${appliedAmount.toFixed(2)} for loan ${loan.loan_code}.`}, 'payment_received')
  `;

  revalidatePath('/collections');
  revalidatePath(`/loans/${loanId}`);
  redirect(`/collections/receipt/${collection.id}`);
}

export async function updateCollectionAction(id: number, formData: FormData) {
  await requireAdmin();

  const amount = Number(formData.get('amount_paid'));
  const method = String(formData.get('payment_method') || 'cash');
  const paymentDate = String(formData.get('payment_date') || new Date().toISOString().slice(0, 10));
  const notes = String(formData.get('notes') || '');

  const [collection] = await sql`SELECT * FROM collections WHERE id = ${id}`;
  if (!collection) redirect('/collections?error=' + encodeURIComponent('Payment record not found.'));
  const loanId = collection.loan_id;

  await sql`
    UPDATE collections SET amount_paid = ${amount}, payment_method = ${method}, payment_date = ${paymentDate}, notes = ${notes}
    WHERE id = ${id}
  `;

  // Recompute every installment on this loan from scratch by replaying every
  // payment in chronological order — the only reliable way to handle an edited
  // historical payment correctly (fragile incremental patching risks drifting
  // out of sync with reality).
  await sql`UPDATE loan_installments SET paid_amount = 0, status = 'pending', paid_date = NULL WHERE loan_id = ${loanId}`;

  const allCollections = (await sql`
    SELECT * FROM collections WHERE loan_id = ${loanId} ORDER BY payment_date ASC, id ASC
  `) as any[];

  for (const c of allCollections) {
    const dateStr = c.payment_date instanceof Date ? c.payment_date.toISOString().slice(0, 10) : String(c.payment_date).slice(0, 10);
    await applyPaymentToInstallments(loanId, Number(c.amount_paid), c.installment_id ?? null, dateStr);
  }

  await sql`UPDATE loan_installments SET status = 'overdue' WHERE status = 'pending' AND due_date < CURRENT_DATE`;
  await recomputeLoanCompletionStatus(loanId);

  revalidatePath(`/loans/${loanId}`);
  revalidatePath('/collections');
  redirect(`/loans/${loanId}`);
}

// ---------- Savings ----------

export async function recordSavingsTransactionAction(borrowerId: number, formData: FormData) {
  const admin = await requireAdmin();

  const type = String(formData.get('type') || 'deposit');
  const amount = Number(formData.get('amount'));
  const notes = String(formData.get('notes') || '');
  const transactionDate = String(formData.get('transaction_date') || new Date().toISOString().slice(0, 10));

  if (amount <= 0) {
    redirect(`/savings/${borrowerId}?error=` + encodeURIComponent('Amount must be greater than zero.'));
  }
  if (type !== 'deposit' && type !== 'withdrawal') {
    redirect(`/savings/${borrowerId}?error=` + encodeURIComponent('Invalid transaction type.'));
  }

  if (type === 'withdrawal') {
    const [row] = await sql`
      SELECT COALESCE(SUM(CASE WHEN type = 'deposit' THEN amount ELSE -amount END), 0) AS balance
      FROM savings_transactions WHERE borrower_id = ${borrowerId}
    `;
    if (Number(row.balance) < amount) {
      redirect(`/savings/${borrowerId}?error=` + encodeURIComponent(`Insufficient savings balance (available: ৳${Number(row.balance).toFixed(2)}).`));
    }
  }

  const receiptNo = await nextSequentialCode('S', 'savings_transactions', 'receipt_no');
  await sql`
    INSERT INTO savings_transactions (borrower_id, receipt_no, type, amount, notes, transaction_date, recorded_by)
    VALUES (${borrowerId}, ${receiptNo}, ${type}, ${amount}, ${notes}, ${transactionDate}, ${admin.adminId})
  `;

  revalidatePath(`/savings/${borrowerId}`);
  revalidatePath('/savings');
  redirect(`/savings/${borrowerId}`);
}

export async function editSavingsTransactionAction(borrowerId: number, transactionId: number, formData: FormData) {
  await requireAdmin();

  const type = String(formData.get('type') || 'deposit');
  const amount = Number(formData.get('amount'));
  const notes = String(formData.get('notes') || '');
  const transactionDate = String(formData.get('transaction_date') || new Date().toISOString().slice(0, 10));

  if (amount <= 0) {
    redirect(`/savings/${borrowerId}?error=` + encodeURIComponent('Amount must be greater than zero.'));
  }
  if (type !== 'deposit' && type !== 'withdrawal') {
    redirect(`/savings/${borrowerId}?error=` + encodeURIComponent('Invalid transaction type.'));
  }

  // Check the resulting balance (excluding this transaction's old value) would stay non-negative
  const [row] = await sql`
    SELECT COALESCE(SUM(CASE WHEN type = 'deposit' THEN amount ELSE -amount END), 0) AS balance
    FROM savings_transactions WHERE borrower_id = ${borrowerId} AND id != ${transactionId}
  `;
  const balanceWithoutThis = Number(row.balance);
  const newBalance = type === 'deposit' ? balanceWithoutThis + amount : balanceWithoutThis - amount;
  if (newBalance < 0) {
    redirect(`/savings/${borrowerId}?error=` + encodeURIComponent('This change would make the savings balance negative.'));
  }

  await sql`
    UPDATE savings_transactions SET type = ${type}, amount = ${amount}, notes = ${notes}, transaction_date = ${transactionDate}
    WHERE id = ${transactionId} AND borrower_id = ${borrowerId}
  `;

  revalidatePath(`/savings/${borrowerId}`);
  revalidatePath('/savings');
  redirect(`/savings/${borrowerId}`);
}

export async function deleteSavingsTransactionAction(borrowerId: number, transactionId: number) {
  await requireAdmin();
  await sql`DELETE FROM savings_transactions WHERE id = ${transactionId} AND borrower_id = ${borrowerId}`;
  revalidatePath(`/savings/${borrowerId}`);
  revalidatePath('/savings');
  redirect(`/savings/${borrowerId}`);
}

// ---------- Site Settings ----------

export async function updateSiteSettingsAction(formData: FormData) {
  await requireAdmin();

  const bannerImage = formData.get('banner_image') as File | null;
  const removeBanner = formData.get('remove_banner_image') === '1';

  if (bannerImage && bannerImage.size > 0) {
    if (bannerImage.size > 3 * 1024 * 1024) {
      redirect('/settings?error=' + encodeURIComponent('Banner image is too large. Max size is 3MB.'));
    }
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(bannerImage.type)) {
      redirect('/settings?error=' + encodeURIComponent('Banner image must be JPG, PNG, or WEBP.'));
    }
    const buffer = Buffer.from(await bannerImage.arrayBuffer());
    const base64 = buffer.toString('base64');
    try {
      await sql`
        UPDATE site_settings SET banner_image_data = ${base64}, banner_image_mime = ${bannerImage.type} WHERE id = 1
      `;
    } catch (err: any) {
      const msg = String(err?.message || '');
      if (msg.includes('banner_image') && msg.includes('does not exist')) {
        redirect('/settings?error=' + encodeURIComponent('Banner upload needs a database update first — run migration_add_banner_image.sql, then try again.'));
      }
      throw err;
    }
  } else if (removeBanner) {
    await sql`UPDATE site_settings SET banner_image_data = NULL, banner_image_mime = NULL WHERE id = 1`;
  }

  await sql`
    UPDATE site_settings SET
      site_name = ${String(formData.get('site_name') || 'MicroLoan')},
      tagline = ${String(formData.get('tagline') || '')},
      banner_heading = ${String(formData.get('banner_heading') || '')},
      banner_subtext = ${String(formData.get('banner_subtext') || '')},
      about_text = ${String(formData.get('about_text') || '')},
      contact_phone = ${String(formData.get('contact_phone') || '')},
      contact_email = ${String(formData.get('contact_email') || '')},
      contact_address = ${String(formData.get('contact_address') || '')},
      savings_interest_rate = ${Number(formData.get('savings_interest_rate') || 0)},
      updated_at = now()
    WHERE id = 1
  `;

  revalidatePath('/settings');
  revalidatePath('/');
  redirect('/settings?saved=1');
}

// ---------- Documents ----------

const MAX_DOC_SIZE = 3 * 1024 * 1024;
// Includes HEIC/HEIF — the default photo format on iPhones — since a phone camera
// photo failing this check silently (looking to the member like "upload doesn't
// work") was a likely real-world cause of upload complaints.
const ALLOWED_DOC_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif', 'application/pdf'];
// Many phone browsers (older Android WebViews, some camera-roll pickers) send a
// blank or generic file.type ('', 'application/octet-stream') for photos instead
// of the real image MIME type. Relying on file.type alone silently rejected real
// photos on those phones — this maps the file's extension as a fallback so the
// same photo that works on one phone isn't randomly refused on another.
const ALLOWED_DOC_EXTENSIONS: Record<string, string> = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp',
  heic: 'image/heic', heif: 'image/heif', pdf: 'application/pdf',
};
const GENERIC_MIME_TYPES = ['', 'application/octet-stream', 'application/octet stream'];

export async function uploadDocumentAction(borrowerId: number, formData: FormData) {
  const admin = await requireAdmin();

  const file = formData.get('file') as File | null;
  const docTitle = String(formData.get('doc_title') || '').trim();
  const docType = String(formData.get('doc_type') || 'other');

  if (!file || file.size === 0) {
    redirect(`/borrowers/${borrowerId}?error=` + encodeURIComponent('Please choose a file to upload.'));
  }
  if (!docTitle) {
    redirect(`/borrowers/${borrowerId}?error=` + encodeURIComponent('Please give the document a title.'));
  }
  if (file.size > MAX_DOC_SIZE) {
    redirect(`/borrowers/${borrowerId}?error=` + encodeURIComponent('File is too large. Max size is 3MB — try a smaller photo or a compressed PDF.'));
  }

  const ext = (file.name.split('.').pop() || '').toLowerCase();
  const extMimeType = ALLOWED_DOC_EXTENSIONS[ext];
  const typeIsAllowed = ALLOWED_DOC_TYPES.includes(file.type);
  const typeIsGenericButExtensionKnown = GENERIC_MIME_TYPES.includes(file.type) && !!extMimeType;
  if (!typeIsAllowed && !typeIsGenericButExtensionKnown) {
    redirect(`/borrowers/${borrowerId}?error=` + encodeURIComponent('Only JPG, PNG, WEBP, HEIC, or PDF files are allowed.'));
  }
  // Store a real MIME type even when the browser handed us a blank/generic one,
  // so the document viewer later on can render it correctly.
  const resolvedMimeType = typeIsAllowed ? file.type : extMimeType;

  const buffer = Buffer.from(await file.arrayBuffer());
  const base64 = buffer.toString('base64');

  await sql`
    INSERT INTO borrower_documents (borrower_id, doc_title, doc_type, file_name, mime_type, file_size, file_data, uploaded_by)
    VALUES (${borrowerId}, ${docTitle}, ${docType}, ${file.name}, ${resolvedMimeType}, ${file.size}, ${base64}, ${admin.adminId})
  `;

  revalidatePath(`/borrowers/${borrowerId}`);
  redirect(`/borrowers/${borrowerId}?uploaded=1#documents`);
}

export async function deleteDocumentAction(borrowerId: number, docId: number) {
  await requireAdmin();
  await sql`DELETE FROM borrower_documents WHERE id = ${docId} AND borrower_id = ${borrowerId}`;
  revalidatePath(`/borrowers/${borrowerId}`);
  redirect(`/borrowers/${borrowerId}#documents`);
}

// ---------- Notifications ----------

export async function markNotificationReadAction(id: number) {
  await requireAdmin();
  await sql`UPDATE notifications SET is_read = true WHERE id = ${id}`;
  revalidatePath('/notifications');
}

export async function markAllNotificationsReadAction() {
  await requireAdmin();
  await sql`UPDATE notifications SET is_read = true`;
  revalidatePath('/notifications');
}
